import {settings} from './app/settings.js'
let app =  new brainsatplay.Application(settings)
app.init()